<!DOCTYPE html>
<html>
<head>
<script>

    function do_this(){

        var checkboxes = document.getElementsByName('check_list[]');
        var button = document.getElementById('toggle');

        if(button.value == 'select_all'){
            for (var i in checkboxes){
                checkboxes[i].checked = 'FALSE';
            }
            button.value = 'deselect_all'
        }else{
            for (var i in checkboxes){
                checkboxes[i].checked = '';
            }
            button.value = 'select_all';
        }
    }
</script>
<style>
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
	
    background-color: white;
	font-size: 150%;
	margin-right: 80px;
    margin-left: 80px;
	box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}

li {
    float: left;
}

li a {
    display: block;
    color: black;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover {
	 background-color: green;
	color:white;
}
body {
    background-color: #eae7e5;
	 overflow:hidden;
}

.hover {
	 background-color: green;
	color:white;
}
s{
	 background-color: green;
	color:white;
}
.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 12px 36px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
	margin-right: 50px;
    margin-left: 79px;
	
}
.button:visited, .button:hover{
	box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}
.button1 {width: 250px;}

.side:link, .side:visited {
    background-color: #4CAF50;
    color: white;
    padding: 10px 10px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
	width: 200px;
	margin-right: 50px;
    margin-left: 79px;
	font-size: 120%;
	
}


.side:hover, .side:active {
    background-color: #4E9326;
	box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}
h2{
 margin-left: 79px;
}
div
{
	margin-left: 350px;
	margin-right: 80px;
	border: 1px dark green;
    margin-top: -120px;
    margin-bottom: 80px;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
	background-color: white;
}
.top:link, .top:visited {
    background-color: #eae7e5;
    color: black;
    border: 2px solid green;
    padding: 10px 20px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
}

.top:hover, .top:active {
    background-color: green;
    color: white;
}
</style>
</head>
<body>
<!--<a  href="#" style="margin-right: 79px;"  >Semester 1</a>-->
<h3><a href="#" style=" font-size: 30px;margin-right: 940px; text-decoration:none; padding-left:80px">E-Notifier</a> <a href="logout.php" class="top">Logout</a></h3>
<ul>
   <li><a href="sem_wise_course.php?sem=<?php echo "3";?>" >Students </a></li>
  <li><a href="parent_wise_course.php?sem=3">Parents</a></li>
  <li><a href="alumni_wise.php?sem=2013">Alumni</a></li>
  <li><a href="#" class="hover">Others</a></li>
  
 
</ul>
<br><br>

<a href="sem_wise_course.php?sem=<?php echo "3";?>"  class="side" name="s" >Move to Alumni</a><br><br>
<a href="#"  class="side" name="s" >Import data</a><br><br>
<div  style="">
		<form method="post" action="change_pass_con.php">
    <input name="t1" type="text" id="t1" size="40" placeholder="Username" required>
	<br><br>
	<input name="t2" type="text" id="t2" size="40" placeholder="Password" required>
	<br><br>
	<input name="t3" type="text" id="t3" size="40" placeholder=" New Password" required>
	<br><br>
	<input name="t4" type="text" id="t4" size="40" placeholder="Confirm Password" required>
	<br><br>
     <input name="submit" class="button" type="submit"  value="submit"><br>
	
  </form>
						
						 
</div>

</form>
</body>
</html>
