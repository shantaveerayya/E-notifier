<!DOCTYPE html>
<html>
<head>
<style>
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: white;
	font-size: 150%;
	margin-right: 80px;
    margin-left: 80px;
}

li {
    float: left;
}

li a {
    display: block;
    color: blue;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover {
    border-style: solid;
	 border-bottom: thick solid #ff0000;
	 border-color:red;

}
body {
    background-color: #eae7e5;
	 overflow:hidden;
}
.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
	margin-right: 50px;
    margin-left: 79px;
}

.button1 {width: 250px;}
.side:link, .side:visited {
    background-color: #f44336;
    color: white;
    padding: 14px 25px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
	width: 220px;
	margin-right: 50px;
    margin-left: 79px;
	font-size: 120%;
}


.side:hover, .side:active {
    background-color: red;
}
h2{
 margin-left: 79px;
}
div
{
	margin-left: 400px;
	margin-right: 70px;
	border: 1px dark green;
    margin-top: -325px;
    margin-bottom: 80px;
    
}
</style>
</head>
<body>
<h2>E-Notifier</h2>
<!--<a  href="#" style="margin-right: 79px;"  >Semester 1</a>-->
<br>
<ul>
  <li><a class="active" href="#home">To Students</a></li>
  <li><a href="#news">To parents</a></li>
  <li><a href="alumni_wise.php">To Alumni</a></li>
  
 
</ul>
<br><br>

<a href="#" class="side" >Semester 1</a><br><br><br>
<a href="default.asp" class="side" >Semester 2</a><br><br><br>
<a href="default.asp" class="side" >Semester 3</a><br><br><br>
<a href="default.asp" class="side" >Semester 4</a><br><br><br>

<div  style="border:1px solid red">
j
</div>
</body>
</html>
