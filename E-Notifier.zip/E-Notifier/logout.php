<?php
session_start();
session_destroy();
?>
<script>
document.location="index.html";
</script>