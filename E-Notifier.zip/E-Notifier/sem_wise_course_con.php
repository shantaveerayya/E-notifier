<?php

$cno = $_POST['check_list'];
$sem=$_POST['sem'];

$notice=$_POST['notice'];


$con=mysql_connect("localhost","root","");
mysql_select_db("bbs",$con);

$sql="select * from messagesend where sem='$sem'";


$res=mysql_query($sql);

//print_r($cno);
   



$url="http://promo.chandnas.com/api/web2sms.php?workingkey=A26f0723ccd4d21270bfb2139ba941632&sender=BULKSMS&to=$cno&message=$notice";

header("Location:$url");

?>
