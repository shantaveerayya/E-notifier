
<!DOCTYPE html>
<html>
<head>
<script>

    function do_this(){

        var checkboxes = document.getElementsByName('check_list[]');
        var button = document.getElementById('toggle');

        if(button.value == 'select_all'){
            for (var i in checkboxes){
                checkboxes[i].checked = 'FALSE';
            }
            button.value = 'deselect_all'
        }else{
            for (var i in checkboxes){
                checkboxes[i].checked = '';
            }
            button.value = 'select_all';
        }
    }
</script>
<style>
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
	
    background-color: white;
	font-size: 150%;
	margin-right: 80px;
    margin-left: 80px;
	box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}

li {
    float: left;
}

li a {
   display: block;
    color: black;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover {
  background-color: green;
  color:white;

}
body {
    background-color: #eae7e5;
	 overflow:hidden;
}
.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 12px 36px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
	margin-right: 50px;
    margin-left: 79px;
}

.button1 {width: 250px;}
.side:link, .side:visited {
    background-color: #4CAF50;
    color: white;
    padding: 10px 10px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
	width: 200px;
	margin-right: 50px;
    margin-left: 79px;
	font-size: 120%;
}


.side:hover, .side:active {
    background-color: #4E9326;
}
h2{
 margin-left: 79px;
}
.button:visited, .button:hover{
	box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}
div
{
	margin-left: 350px;
	margin-right: 80px;
	border: 1px dark green;
    margin-top: -360px;
    margin-bottom: 80px;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
	background-color: white;
}
.log
{
	 border: solid;
	 display: block;
}
.top:link, .top:visited {
    background-color: #eae7e5;
    color: black;
    border: 2px solid green;
    padding: 10px 20px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
}

.top:hover, .top:active {
    background-color: green;
    color: white;
}
</style>
</head>
<body>

<!--<a  href="#" style="margin-right: 79px;"  >Semester 1</a>-->
<h3><a href="#" style=" font-size: 30px;margin-right: 940px; text-decoration:none; padding-left:80px">E-Notifier</a> <a href="#" class="top">Logout</a></h3>
<ul>
   <li><a href="sem_wise_course.php?sem=1">Students </a></li>
  <li><a href="parent_wise_course.php?sem=1">Parents</a></li>
  <li><a href="alumni_wise.php?sem=2013">Alumni</a></li>
  <li><a href="others.php">Others</a></li>
  
 
</ul>
<br><br>

<a href="sem_wise_course.php?sem=<?php echo "1";?>"  class="side" >Semester 1</a><br><br>
<a href="sem_wise_course.php?sem=<?php echo "2";?>" class="side" >Semester 2</a><br><br>
<a href="sem_wise_course.php?sem=<?php echo "3";?>"  class="side" >Semester 3</a><br><br>
<a href="sem_wise_course.php?sem=<?php echo "4";?>"  class="side" >Semester 4</a><br><br>
<a href="sem_wise_course.php?sem=<?php echo "5";?>"  class="side" >Semester 5</a><br><br>
<a href="sem_wise_course.php?sem=<?php echo "6";?>"  class="side" >Semester 6</a><br><br>
<div  style="">
		<?php
				if(empty($_POST['check_list']))
				{
		?>
		<script>
			alert("select atleast one checkbox");
				window.history.back();
		</script>
		<?php
				}
				$arr=implode(",",$_POST['check_list'])
		
				?>
		<form name="check"action="sem_wise_course_con.php" method="post">
			<input type="hidden" name="sem" value="<?php echo $_POST['sem']; ?>">
			
			<input type="hidden" name="check_list" value="<?php echo $arr; ?>">
			
						 
						<table  border="0" width="300">
                          
                  <tr>
                  <td bgcolor="#4E9326" style="color:white;" width="300"><h4 align="center">Enter Message</h4></td>
                  </tr>
                         <tr>
                            <td width="300"><label>
                              <textarea name="notice" id="notice" class="textarea" cols="45" rows="5"  placeholder="Enter Message" required></textarea>
                            </label></td>
                          </tr>
                           
                            
                          
        
                        </table>
						<!---<table width="397" border="1">
                          
						  
                        </table>-->
						<br>
						 
						
</div>
<input type="submit" value="proceed" class="button"style="margin-left: 1130px;"onClick="if(!this.check.check_list.checked){alert('Select atleast one contact.'); return false}">
 </form>
</body>
</html>
