<!DOCTYPE html>
<html>
<head>
<style>
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
	
    background-color: white;
	font-size: 150%;
	margin-right: 80px;
    margin-left: 80px;
	box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}

li {
    float: left;
}

li a {
    display: block;
    color: dodger blue;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover {
    background-color: green;
  color:white;

}
body {
    background-color: #eae7e5;
	 overflow:hidden;
}
.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
	margin-right: 50px;
    margin-left: 79px;
}

.button1 {width: 250px;}
.side:link, .side:visited {
    background-color: #f44336;
    color: white;
    padding: 10px 10px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
	width: 200px;
	margin-right: 50px;
    margin-left: 79px;
	font-size: 120%;
}


.side:hover, .side:active {
    background-color: ;
}
label{
 margin-left: 79px;
 font-size: 150%;
}
div
{
	
    width: 700px;
    border: 10px dark green;
    padding: 10px;
    margin-top: -220px;
    margin-bottom: 120px;
    margin-right: 100px;
    margin-left: 390px;
	
    
}
.top:link, .top:visited {
    background-color: #eae7e5;
    color: black;
    border: 2px solid green;
    padding: 10px 20px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
}

.top:hover, .top:active {
    background-color: green;
    color: white;
}
img {
    max-width: 100%;
    height: auto;
	margin:auto;
}
</style>
</head>
<body>
<h3><a href="#" style=" font-size: 30px;margin-right: 940px; text-decoration:none; padding-left:80px">E-Notifier</a> <a href="logout.php" class="top">Logout</a></h3>
<ul>
  <li><a href="sem_wise_course.php?sem=3">Students </a></li>
  <li><a href="parent_wise_course.php?sem=3">Parents</a></li>
  <li><a href="alumni_wise.php?sem=2013">Alumni</a></li>
  <li><a href="others.php">Others</a></li>
  
  
 
</ul>

<br><br>

<br><br>
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>
<div>
  &nbsp; &nbsp;&nbsp; &nbsp; <img src="m.png">
</div>
</body>
</html>
