
 <?php
 
 $data1 = $_POST['data'];
			$con=mysql_connect("localhost","root","");
            mysql_select_db("bbs",$con);
          if(!$con)
			echo "Mysql Error".mysql_error()."<br>";
						
			?>

<?php
$CSVfp = fopen($data1, "r");
if($CSVfp !== FALSE) {
print "<PRE>";
while(! feof($CSVfp)) {
	$data = fgetcsv($CSVfp, 1000, ",");
	$sql="INSERT INTO messagesend VALUES ('" . $data[0] . "', '" . $data[1] . "', '" . $data[2] . "','" . $data[3] . "','" . $data[4] . "','" . $data[5] . "','" . $data[6] . "','" . $data[7] . "','" . $data[8] . "');\r\n\n";
	$res=mysql_query($sql);
	
}

fclose($CSVfp);
}
else{
	echo "Something got error";
	
}

?>