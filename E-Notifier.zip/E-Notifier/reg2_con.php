<?php
$course=$_POST['course'];
$year=$_POST['year'];
$sem=$_POST['sem'];
$name=$_POST['name'];
$regno=$_POST['regno'];
$cno=$_POST['cno'];
$email=$_POST['email'];
$pname=$_POST['pname'];
$pno=$_POST['pno'];


$con=mysql_connect("localhost","root","");

if(!$con)
	echo "Mysql Error".mysql_error()."<br>";

mysql_select_db("bbs",$con);


  
$sql="insert into messagesend values('$course','$year','$sem','$name','$regno','$cno','$email','$pname','$pno')";
$res=mysql_query($sql);

if(!$res){
	echo "Mysql Error".mysql_error()."<br>";
}
else
{
?>
<script>
alert("Registered Successfully..!!");
window.location="index.html";
</script>
<?php
}
?>