<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<script>

    function do_this(){

        var checkboxes = document.getElementsByName('check_list[]');
        var button = document.getElementById('toggle');

        if(button.value == 'select_all'){
            for (var i in checkboxes){
                checkboxes[i].checked = 'FALSE';
            }
            button.value = 'deselect_all'
        }else{
            for (var i in checkboxes){
                checkboxes[i].checked = '';
            }
            button.value = 'select_all';
        }
    }
	
	function myfunction()
	{
		document.getElementById("foo").style.backgroundColor = "green";
		document.getElementById("foo").style.color = "white";
		
	}
</script>
<style>
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
	
    background-color: white;
	font-size: 150%;
	margin-right: 80px;
    margin-left: 80px;
	box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}

li {
    float: left;
}

li a {
    display: block;
    color: black;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover {
	 background-color: green;
	color:white;
}
body {
    background-color: #eae7e5;
	 overflow:hidden;
}

.hover {
	 background-color: green;
	color:white;
}
s{
	 background-color: green;
	color:white;
}
.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 12px 36px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
	margin-right: 50px;
    margin-left: 79px;
	
}
.button:visited, .button:hover{
	box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}
.button1 {width: 250px;}

.side:link, .side:visited {
    background-color: #4CAF50;
    color: white;
    padding: 10px 10px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
	width: 200px;
	margin-right: 50px;
    margin-left: 79px;
	font-size: 120%;
	
}


.side:hover, .side:active {
    background-color: #4E9326;
	box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}
h2{
 margin-left: 79px;
}
div
{
	margin-left: 350px;
	margin-right: 80px;
	border: 1px dark green;
    margin-top: -110px;
    margin-bottom: 80px;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
	background-color: white;
}
.top:link, .top:visited {
    background-color: #eae7e5;
    color: black;
    border: 2px solid green;
    padding: 10px 20px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
}

.top:hover, .top:active {
    background-color: green;
    color: white;
}
</style>
</head>
<body>
<!--<a  href="#" style="margin-right: 79px;"  >Semester 1</a>-->
<h3><a href="#" style=" font-size: 30px;margin-right: 940px; text-decoration:none; padding-left:80px">E-Notifier</a> <a href="logout.php" class="top">Logout</a></h3>
<ul>
   <li><a href="sem_wise_course.php?sem=3" >Students </a></li>
  <li><a href="parent_wise_course.php?sem=3">Parents</a></li>
  <li><a href="#" class="hover">Alumni</a></li>
  <li><a href="others.php">Others</a></li>
  
 
</ul>
<br><br>
<?php
$sem=$_GET['sem'];
						
			$con=mysql_connect("localhost","root","");
            mysql_select_db("bbs",$con);
            $sql="select distinct year from alumni order by year ASC";
						
			$res=mysql_query($sql);
			while($row=mysql_fetch_array($res))
            {
?>		
<a  href="alumni_wise.php?sem=<?php echo $row['year'];?>"  class="side" ><?php echo $row['year']; ?> </a><br><br>
				
<?php
			}
			?>
<div  style="">
		
		<form name="check"action="alumni_message.php" method="post">
         <?php
			$sem=$_GET['sem'];
						
			$con=mysql_connect("localhost","root","");
            mysql_select_db("bbs",$con);
            $sql="select * from alumni where year='$sem'";
						
			$res=mysql_query($sql);
						?>
						<table  border="0" width="900">
                          <input type="hidden" name="sem" value="<?php echo $sem;?>">
                  <tr>
                  
                    <td bgcolor="#4E9326" style="color:white;" ><h4 align="center">Student Name</h4></td>
                    <td bgcolor="#4E9326" style="color:white;"><h4 align="center">Contact No</h4></td>
                    <td bgcolor="#4E9326" style="color:white;"><h4 align="center">Select to Send</h4></td>
                 
                        </tr>
                         
                            <tr>
                            
							 <td>&nbsp;</td>
							<td>&nbsp;</td>
                            
                           <td>
                         
                             
                               <input type="button" id="toggle" onClick="do_this()" value="select_all" />
                             </td>
            
							
                          </tr>
						  <tr>
                        <?php
							
                        while($row=mysql_fetch_array($res))
                         {
						?>
                          
                          <tr>
                          <td>
                              <input type="text" name="t1" value="<?php echo $row['alumnistudent'];?>">
                          </td>
                          <td>
                              <input type="text" name="t2" value="<?php echo $row['contactno']; ?>">
                          </td>
                          <td>
                                <input type="checkbox"name="check_list[]"  value="<?php echo $row['contactno'];?>"/>
                                
                            </td>
                           
                          </tr>
                          
                           
  
   
                         <?php
	  
							}
						?>
        
                        </table>
						<!---<table width="397" border="1">
                          <tr>
                            <td width="387"><label>
                              <textarea name="notice" id="notice" class="textarea" cols="45" rows="5"  placeholder="Enter Message" required></textarea>
                            </label></td>
                          </tr>
						  
                        </table>-->
						 <br>
						 
</div>
<input type="submit" value="proceed" class="button"style="margin-left: 1130px;">
</form>
</body>
</html>
