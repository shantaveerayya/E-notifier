<?php
session_start();
?>
<?php

$con=mysql_connect("localhost","root","");
mysql_select_db("bbs",$con);

//get the posted values
$username= $_POST['u'];
$password = $_POST['p'];


//Check for Administrator login
$sql="select * from login where username='$username' and password='$password'";

$result=mysql_query($sql);
$row=mysql_fetch_array($result);

if(mysql_num_rows($result)>0)
{

$username=$row['username']; //fetching a perticular username row

$type=$row['type']; //fetching a role of user

$_SESSION['user']= $username; //initializing a Session variable
$_SESSION['role']=$type; //initializing a role of user




if($type=="staff")
{
?>
<script>

		document.location="staff_home.php";
	</script>
	<?php
}
	
	if($type=="admin")
	{
	?>
	<script>
		document.location="sem_wise.php";
	</script>
	<?php
	}
	else if($type=="stud")
	{
	?>
	<script>
		document.location="student_home.php"
	</script>
	<?php
	}

	else if($type=="princi")
	{
	?>
	<script>

		document.location="princi_home.php";
	</script>
	<?php
    }
	
	else if($type=="hod")
	{
	?>
	<script>

		document.location="hod_home.php";
	</script>
	<?php
    }
}
else

	{
		?>
		<script>
			alert('Invalid username or password...');
			document.location="index.html";
		</script>
		<?php
	
}
?>