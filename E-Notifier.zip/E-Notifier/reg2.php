<!DOCTYPE html>
<html>
<head>
<style>
div {
    background-color: white;
    width: 400px;
    border: 10px dark green;
    padding: 120px;
    margin-top: 10px;
    margin-bottom: 120px;
    margin-right: 100px;
    margin-left: 340px;
	box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}
input[type=text] {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    box-sizing: border-box;
}
input[type=password] {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    box-sizing: border-box;
}
.button {
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}
body {
    background-color: #eae7e5;
	 
}
</style>
</head>
<body>

<h2>E-Notifier</h2>



<div>
<label style="color:DodgerBlue";>Personal Details<label>
<form method="post" action="reg2_con.php">
   
   <input type="hidden" name="course" value ="<?php echo $_POST['course']; ?>">
    <input type="hidden" name="year" value ="<?php echo $_POST['year']; ?>">
	 <input type="hidden" name="sem" value ="<?php echo $_POST['sem']; ?>">
	  <input type="hidden" name="regno" value ="<?php echo $_POST['regno']; ?>">
	<input name="name" type="text" id="p" size="40" placeholder="student name" required>
	<input name="cno" type="text" id="p" size="40" placeholder="contact Number" required>
	<input name="text" type="email" id="p" size="40" placeholder="Email Id" required>
	<input name="pname" type="text" id="p" size="40" placeholder="Parent name" required>
	<input name="pno" type="text" id="p" size="40" placeholder="Parent number" required>
	<br><br>
     <input name="submit" class="button" type="submit"  value="Next"> &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<br>
	 
	
  </form>
</div>

</body>
</html>