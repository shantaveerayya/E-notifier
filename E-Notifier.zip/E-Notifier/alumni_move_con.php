
<?php

$con=mysql_connect("localhost","root","");
mysql_select_db("bbs",$con);

$sql = "insert into alumni(year,alumnistudent,contactno) select year_of_join,studentname,contactno from messagesend where sem='6'";
mysql_query($sql);

$sql="delete from messagesend where sem='6'";
mysql_query($sql);
?>

<script>
alert("Successfully Moved..!!");
document.location="others.php";
</script>
