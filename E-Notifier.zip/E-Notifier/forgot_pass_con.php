<?php
$username=$_POST['u'];
$contact=$_POST['c'];


$con=mysql_connect("localhost","root","");

if(!$con)
	echo "Mysql Error".mysql_error()."<br>";

mysql_select_db("bbs",$con);


$sql="select * from login where username='$username' AND mobileno='$contact'";

$result=mysql_query($sql);
if(!$result)
	echo "Mysql Error".mysql_error()."<br>";
$row=mysql_fetch_array($result);

if(mysql_num_rows($result))
{
?>
<script>
alert("USer exists");
</script>
<?php
$password=$row['password'];

echo $password;

$url="http://promo.chandnas.com/api/web2sms.php?workingkey=A26f0723ccd4d21270bfb2139ba941632&sender=BULKSMS&to=$contact&message= E-Notifier your  password is $password";

header("Location:$url");
}
else
{
?>
<script>
//echo"Sorry.!! You Haven't Registered only";
alert("Username or Contact No Wrong..!!");
document.location ="forgot_pass.html";
</script>
<?php
}
?>


